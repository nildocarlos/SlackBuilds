/**
 * 
 */
package edu.internet2.middleware.grouper.ui.util;

import java.util.List;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author mchyzer
 * 
 */
public class GrouperUiUtilsTest extends TestCase {
	/**
	 * Method main.
	 * 
	 * @param args
	 *            String[]
	 */
	public static void main(String[] args) {
		TestRunner.run(GrouperUiUtilsTest.class);
	}

	/** placeholder for test */
	public void testWhatever() {
	  //nothing
	}
	
}
