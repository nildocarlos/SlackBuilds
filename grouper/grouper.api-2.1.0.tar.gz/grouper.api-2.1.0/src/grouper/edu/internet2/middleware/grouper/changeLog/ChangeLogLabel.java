/*
 * @author mchyzer
 * $Id: ChangeLogLabel.java,v 1.1 2009-06-10 05:31:35 mchyzer Exp $
 */
package edu.internet2.middleware.grouper.changeLog;


/**
 * look in ChangeLogLabels for 
 */
public interface ChangeLogLabel {
  
  /**
   * get the name of the enum
   * @return the name
   */
  public String name();
  
}
