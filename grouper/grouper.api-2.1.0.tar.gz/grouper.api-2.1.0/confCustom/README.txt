Drop config files to be used with gsh

There should be no config files committed in this directory