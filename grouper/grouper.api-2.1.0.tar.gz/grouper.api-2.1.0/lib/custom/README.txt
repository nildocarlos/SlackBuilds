LDAP 3.2 README

    This is the 3.2 release of the VT LDAP Java libraries.
    It is dual licensed under both the LGPL and Apache 2.
    If you have questions or comments about this library contact
    Middleware Services (middleware@vt.edu).

DOCUMENTATION
    See the wiki: http://code.google.com/p/vt-middleware/wiki/vtldap

