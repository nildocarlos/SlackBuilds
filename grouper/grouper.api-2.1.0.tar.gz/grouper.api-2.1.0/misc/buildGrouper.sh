#!/bin/bash

if [ $# -ne "1" ]
then
  echo
  echo "Give the branch to build as the command line argument!"
  echo "e.g. trunk, GROUPER_1_6_BRANCH, etc"
  echo "e.g. buildGrouper.sh GROUPER_1_6_0"
  echo
  exit 1
fi  

cd /tmp
if [ ! -d /home/mchyzer/tmp/grouper ]; then
  /bin/mkdir /home/mchyzer/tmp/grouper
  /bin/chmod g+w /home/mchyzer/tmp/grouper
fi

cd /home/mchyzer/tmp/grouper

export buildDir=/home/mchyzer/tmp/grouper/build_$USER

if [ -d $buildDir ]; then
  /bin/rm -rf $buildDir
fi

if [ ! -d $buildDir ]; then
  /bin/mkdir $buildDir
fi

cd $buildDir

#export CVSROOT=/home/cvs/i2mi

#/usr/bin/cvs export -r $1 grouper

if [ $1 == 'trunk' ]; then
  /usr/bin/svn export https://svn.internet2.edu/svn/i2mi/trunk/grouper/
else
  /usr/bin/svn export https://svn.internet2.edu/svn/i2mi/tags/$1/grouper/
fi

cd $buildDir/grouper

$ANT_HOME/bin/ant distPackage

$ANT_HOME/bin/ant distBinary

mv $buildDir/grouper/dist/binary/*.tar.gz $buildDir/

$M2_HOME/bin/mvn install -DskipTests

echo
echo "regular result is in $buildDir/" 
echo "binary result is in $buildDir/" 
echo

#allow someone from group to delete later on
/bin/chmod -R g+w $buildDir